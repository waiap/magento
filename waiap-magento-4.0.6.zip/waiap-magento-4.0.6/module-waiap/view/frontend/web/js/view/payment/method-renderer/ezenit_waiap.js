define(
  [
    'ko',
    'Magento_Checkout/js/view/payment/default',
    'Magento_Checkout/js/model/quote',
    'Magento_Customer/js/model/customer',
    'mage/translate',
    'mage/url',
    'jquery',
    'Magento_Checkout/js/model/payment/additional-validators',
    'Magento_Checkout/js/model/customer-email-validator',
    'Magento_Checkout/js/model/shipping-save-processor/default',
    'domReady!'
  ],
  function (
    ko,
    Component,
    quote,
    customer,
    $t,
    url,
    $,
    additionalValidators,
    loginValidator,
    shippingSaveProcessor
  ) {
    'use strict';

    return Component.extend({
      amount: null,
      processedRedirect: false,
      pwall_client: null,
      pwall_checkout: null,
      defaults: {
        template: 'Ezenit_Waiap/payment/form'
      },
      initialize: function () {
        this._super().observe(["totals", "amount"]);
        this.loadStylesInHead();
        this.totalsUpdated();
      },
      totalsUpdated: function () {
        this.totals(quote.totals());
        this.amount(parseFloat(this.totals().grand_total) + parseFloat(this.totals().tax_amount));
        if (this.pwall_checkout !== null) {
          this.pwall_checkout.isSelected(this.isCheckedPaymentMethod());
          this.pwall_checkout.amount(this.amount());
        }
        this.log("TOTALS UPDATED", this.totals(), this.amount());
      },
      afterRender: function () {
        this.log("HAS RENDERED");
        this.addObservables();
        this.initializePWallClient();
        if (this.pwall_client.parseUrlParams('request_id') && this.pwall_client.parseUrlParams('method')) {
          $("input[id ^= 'agreement_']").trigger('click');
          $("#ezenit_waiap").trigger('click');
        }
      },
      addObservables: function () {
        this.valid = ko.computed(function () {
          quote.shippingAddress();
          quote.shippingMethod();
          quote.totals();
          quote.paymentMethod();
          if (this.isValidPaymentMethod()) {
            return parseFloat(quote.totals().grand_total) + parseFloat(quote.totals().tax_amount);
          } else {
            return -1;
          }
        }.bind(this));
        this.valid.subscribe(function (newValue) {
          this.checkAndSaveShippingInformation(newValue);
        }.bind(this));
      },
      initializePWallClient: function () {
        if (this.pwall_client === null) {
          this.pwall_client = new PWall(this.config().environment, true);
        }
        if (this.pwall_checkout === null) {
          this.pwall_checkout = this.pwall_client.checkout();
        }
        
        this.pwall_checkout
          .appendTo("#waiap-app")
          .backendUrl(this.config().backend_url)
          .validateForm(this.isValidPaymentMethod.bind(this))
          if (!customer.isLoggedIn()) {
            this.pwall_checkout.validateFields({
              "input[id ^= 'agreement_']": "required",
              "form[data-role=email-with-possible-login] input[name=username]": PWall.VALIDATE_EMAIL
            })
          }else{
            this.pwall_checkout.validateFields({
              "input[id ^= 'agreement_']": "required",
            })
          }
          this.pwall_checkout.on("beforeValidation", this.checkQuote.bind(this))
          .on("paymentOk", this.redirectToCheckoutSuccess)
          .submitButton('.action.primary.checkout')
          .isSelected(this.isCheckedPaymentMethod())
          .amount(this.amount())
          .currency(this.totals().base_currency_code)
          .groupId(customer.isLoggedIn() ? customer.customerData.group_id : 0)
      }, 
      checkAndSaveShippingInformation: function (value) {
        this.totalsUpdated();
        if (value === -1) {
          this.pwall_checkout.isSelected(this.isCheckedPaymentMethod());
          this.renderWarning();
        } else {
          shippingSaveProcessor.saveShippingInformation();
        }
      },
      renderWarning: function () {
        if (this.isCheckedPaymentMethod()){
          $("#waiap-app").append("<p>" + $t('Please, check missing or invalid fields') + "</p>");
        }
      },
      checkQuote: function () {
        if (quote.billingAddress() && quote.billingAddress().canUseForBilling()) {
          // check customer
          var payload = {};
          if (customer.isLoggedIn()) {
            payload.isLoggedIn = true;
            payload.email = customer.getDetails('email');
          } else {
            payload.isLoggedIn = false;
            payload.email = quote.guestEmail;
          }
          $.ajax({ url: this.config().check_url, dataType: "json", data: payload, timeout: 30000 })
            .done(function (data) {
              if (data.success == "true") {
                this.log("QUOTE OK");
              } else {
                this.log("QUOTE KO");
              }
            }.bind(this))
            .fail(this.log("QUOTE KO"));
        } else {
          return this.log("Billing address not valid yet");
        };
      },
      isValidPaymentMethod: function () {
        return this.isCheckedPaymentMethod() && additionalValidators.validate() && loginValidator.validate();
      },
      isCheckedPaymentMethod: function () {
        var checked_payment = quote.paymentMethod() ? quote.paymentMethod().method : null;
        return checked_payment === this.getCode();
      },
      redirectToCheckoutSuccess: function(){
        var redirectUrl = url.build("checkout/onepage/success", {});
        window.location.href = redirectUrl;
      },
      //GETTERS AND CONFIG
      config: function () {
        return window.checkoutConfig.payment[this.getCode()];
      },
      getCode: function () {
        return 'ezenit_waiap';
      },
      getSubTitle: function () {
        return '';
      },
      log: function () {
        if (this.config().debug !== "0") {
          var args = Array.prototype.slice.call(arguments, 0);
          args.unshift("[WAIAP DEBUG]");
          console.log.apply(console, args);
        }
      },
      getCSShref: function () {
        return this.config().environment_url + "pwall_app/css/app.css";
      },
      loadStylesInHead: function () {
        // css include
        var l = document.createElement("link");
        l.rel = "stylesheet";
        l.href = this.getCSShref();
        $("head").append(l);
      },
      /**
       * Place order.
       */
      placeOrder: function (data, event) {
        var self = this;

        if (event) {
          event.preventDefault();
        }
        return false;
      },
    });
  }
);
