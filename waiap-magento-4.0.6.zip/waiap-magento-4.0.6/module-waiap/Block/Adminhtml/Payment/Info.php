<?php

namespace Ezenit\Waiap\Block\Adminhtml\Payment;

use Magento\Framework\Phrase;
use Magento\Payment\Block\ConfigurableInfo;

class Info extends ConfigurableInfo
{
  protected $helper;
  protected $registry;

  public function __construct(
      \Magento\Framework\View\Element\Template\Context $context,
      \Magento\Payment\Gateway\ConfigInterface         $config,
      \Magento\Framework\Registry                      $registry,
      \Ezenit\Waiap\Helper\Data                        $helper,
      \Ezenit\Waiap\Model\PaymentMethod                $waiapPaymentMethod,
      array $data = []
  ) {
      parent::__construct($context, $config, $data);
      $this->helper                 = $helper;
      $this->registry               = $registry;
      $this->waiap_payment_method   = $waiapPaymentMethod; 
  }

  public function getFlattenedData(){
    $order = $this->registry->registry('current_order');
    $payment_method = $order->getPayment();
    if($payment_method->getMethodInstance()->getCode() == $this->waiap_payment_method->getCode()){
      return $this->helper->getFlattenJson(
        json_decode($order->getPayment()->getAdditionalInformation()["response"][0], true)
      );
    }
  }
}
