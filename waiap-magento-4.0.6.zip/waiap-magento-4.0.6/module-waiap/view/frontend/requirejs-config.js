/*jshint browser:true jquery:true*/
/*global alert*/
var config = {
    map: {
        '*': {
            'ezenit_waiap': 'Ezenit_Waiap/js/ezenit_waiap'
        }
    }
};
