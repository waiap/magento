<?php

namespace Ezenit\Waiap\Plugin\Canonical;

/**
 * Head
 */
class Head{

  protected $helper_data;

  public function __construct(
    \Ezenit\Waiap\Helper\Data $helperData
  )
  {
    $this->helper_data = $helperData;
  }


  public function aroundRenderMetadata($subject,$proceed)
  {
    $result = $proceed();
    // Add SDK bundle js
    $sdk_js = null;
    if (array_key_exists($this->helper_data->getConfig('payment/ezenit_waiap/environment'), \Ezenit\Waiap\Helper\Constants::ENVIROMENTS_URLS)) {
      $sdk_js = \Ezenit\Waiap\Helper\Constants::ENVIROMENTS_URLS[$this->helper_data->getConfig('payment/ezenit_waiap/environment')] . 'pwall_sdk/pwall_sdk.bundle.js';
    }  
    $url = '
    <script type="text/javascript" src="'.$sdk_js.'"></script>'.PHP_EOL.
    '<script type="text/javascript" src="'. \Ezenit\Waiap\Helper\Constants::SDK_JS_URL.'"></script>';
    return $result.$url;
  }
}