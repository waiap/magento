<?php

namespace Ezenit\Waiap\Model\Config;

class Provider implements \Magento\Checkout\Model\ConfigProviderInterface
{
  const CODE = 'ezenit_waiap';

  protected $config;
  protected $url_builder;

  public function __construct(\Magento\Framework\App\Helper\Context $context)
  {
    $this->config       = $context->getScopeConfig();
    $this->url_builder  = $context->getUrlBuilder();
  }

  public function getConfig()
  {
    return [
        'payment' => [
          self::CODE => [
            'environment'        => $this->config->getValue('payment/ezenit_waiap/environment'),
            'environment_url'   => \Ezenit\Waiap\Helper\Constants::ENVIROMENTS_URLS[$this->config->getValue('payment/ezenit_waiap/environment')],
            'debug'             => $this->config->getValue('payment/ezenit_waiap/debug'),
            'backend_url'       => $this->url_builder->getUrl('waiap/backend/index'),
            'check_url'         => $this->url_builder->getUrl('waiap/check')
          ]
        ]
      ];
  }
}
