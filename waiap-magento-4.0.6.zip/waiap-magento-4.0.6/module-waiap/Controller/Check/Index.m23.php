<?php

namespace Ezenit\Waiap\Controller\Check;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\App\Request\InvalidRequestException;
use Magento\Framework\App\RequestInterface;


class Index extends \Magento\Framework\App\Action\Action implements \Magento\Framework\App\CsrfAwareActionInterface
{

  protected $result_factory;
  protected $config;
  protected $logger;
  protected $checkout;
  protected $request;
  protected $helper;
  protected $quote_repository;

  /**
   * @inheritDoc
   */
  public function createCsrfValidationException(
      RequestInterface $request
  ): ?InvalidRequestException {
      return null;
  }

  /**
   * @inheritDoc
   */
  public function validateForCsrf(RequestInterface $request): ?bool
  {
      return true;
  }


  public function __construct(
      \Magento\Framework\App\Action\Context            $context,
      \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
      \Magento\Checkout\Helper\Data                    $checkoutHelper,
      \Magento\Quote\Api\CartRepositoryInterface       $quoteRepository,
      \Ezenit\Waiap\Helper\Data                        $helper
  )
  {
    $this->result_factory    = $resultJsonFactory;
    $this->request           = $context->getRequest();
    $this->helper            = $helper;
    $this->checkout          = $checkoutHelper;
    $this->quote_repository  = $quoteRepository;
    parent::__construct($context);
  }

  public function execute()
  {
    $this->helper->debug("ON CHECK QUOTE: " . json_encode($this->request->getParams()) );
    $result       = $this->result_factory->create();
    $quote        = $this->checkout->getQuote();
    if(!$quote->getId()||!$quote->getIsActive()){
      $result->setData(["success" => "false"]);
      return $result;
    }
    if($this->request->getParam("isLoggedIn") == "false"){
      $this->helper->debug("NOT LOGGED IN -> UPDATE QUOTE ".$quote->getId());
      $quote->setCustomerId(null);
      $quote->setCustomerEmail($this->request->getParam("email"));
      $quote->setCustomerIsGuest(true);
      $this->quote_repository->save($quote);
    }

    $result->setData(["success" => "true"]);
    return $result;
  }
}
