<?php

namespace Ezenit\Waiap\Helper;

class Data
{

  CONST EXCLUDED_SUSPECTED_FRAUD_METHODS = ["azon", "altp_bizum", "altp"];

  protected $config;
  protected $url_builder;
  protected $log;
  protected $request;
  protected $guest_payment;
  protected $customer_payment;
  protected $payment_method;
  protected $quote_repository;
  protected $quote_management;
  protected $quote_mask_factory;
  protected $order_repository;
  protected $cookie_manager;
  protected $cookie_metadata_factory;

  public function __construct(
    \Magento\Framework\App\Helper\Context                             $context,
    \Magento\Quote\Api\CartRepositoryInterface                        $quoteRepository,
    \Magento\Checkout\Api\GuestPaymentInformationManagementInterface  $guestPaymentManagement,
    \Magento\Checkout\Api\PaymentInformationManagementInterface       $customerPaymentManagement,
    \Magento\Quote\Model\QuoteIdMaskFactory                           $quoteIdMaskFactory,
    \Magento\Quote\Model\QuoteManagement                              $quoteManagement,
    \Magento\Quote\Api\Data\PaymentInterface                          $paymentMethod,
    \Magento\Sales\Model\OrderRepository                              $orderRepository,
    \Magento\Framework\Stdlib\CookieManagerInterface                  $cookieManager,
    \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory            $cookieMetadataFactory,
    \Magento\CheckoutAgreements\Model\AgreementsProvider              $agreementsProvider,
    \Magento\Quote\Api\Data\PaymentExtensionFactory                   $paymentExtension
  ){
    $this->config                   = $context->getScopeConfig();
    $this->url_builder              = $context->getUrlBuilder();
    $this->logger                   = $context->getLogger();
    $this->request                  = $context->getRequest();
    $this->quote_repository         = $quoteRepository;
    $this->quote_management         = $quoteManagement;
    $this->customer_payment         = $customerPaymentManagement;
    $this->guest_payment            = $guestPaymentManagement;
    $this->payment_method           = $paymentMethod;
    $this->quote_mask_factory       = $quoteIdMaskFactory;
    $this->order_repository         = $orderRepository;
    $this->cookie_manager           = $cookieManager;
    $this->cookie_metadata_factory  = $cookieMetadataFactory;
    $this->agreements_provider      = $agreementsProvider;
    $this->payment_extension        = $paymentExtension;

  }

  public function getRequest(){
    return $this->request;
  }

  public function parseJSONRequest($content){
    return json_decode($content,true);
  }

  public function placeOrderFromResponse($response, $method, $quote){
    $this->debug("PAYMENT METHOD!!!: " . $method);
    // add payment method and convert quote to order
    $this->convertQuoteToOrder($quote, $response, $method);
    $this->invalidateCartCookie();
    return true;
  }

  public function convertQuoteToOrder($quote, $response, $method){
    $this->debug("CONVERT TO QUOTE ORDER: ".$quote->getId());
    // prepare payment method
    $this->payment_method->setMethod('ezenit_waiap');
    $this->payment_method->setAdditionalData(json_encode($response->getPaymentInfo()));
    // set agreements ids
    $extension = $this->payment_extension->create();
    $extension->setAgreementIds($this->agreements_provider->getRequiredAgreementIds());
    $this->payment_method->setExtensionAttributes($extension);

    $idMask  = $this->quote_mask_factory->create();
    $cartId  = $idMask->load($quote->getId(), 'quote_id')->getMaskedId();
    $orderId = null;

    if(!$quote->getCustomerIsGuest()&&$quote->getCustomerId()){
      $this->debug("CONVERT TO QUOTE CUSTOMER: ".$quote->getId());
      $orderId = $this->customer_payment->savePaymentInformationAndPlaceOrder(
        $quote->getId(),
        $this->payment_method
      );
    }else{
      $this->debug("CONVERT TO QUOTE GUEST: ".$quote->getId());
      $orderId = $this->guest_payment->savePaymentInformationAndPlaceOrder(
        $cartId,
        $quote->getCustomerEmail(),
        $this->payment_method
      );
    }
    // NO SUSPECTED FRAUD DETECTION UNTIL RESPONSE AMOUNT IN ALL PAYMENT METHODS
    // if($method && !in_array($method, self::EXCLUDED_SUSPECTED_FRAUD_METHODS)){
    //   $flattenResponse = $this->getFlattenJson($response);
    //   $responseAmount = 0;
    //   foreach ($flattenResponse as $key => $value) {
    //     if (strpos($key, 'amount') !== false){
    //       $responseAmount = $value;
    //       break;
    //     }
    //   }
    //   // $responseAmount = $flattenResponse[current(preg_grep('/^amount/', array_keys($flattenResponse)))]

      
    //   if(!in_array($method, self::EXCLUDED_SUSPECTED_FRAUD_METHODS) && ($responseAmount/100 != $quote->getGrandTotal())){
    //     $this->debug("SUSPECTED FROUD DETECTED");
    //     if($orderId != null){
    //       $order = $this->order_repository->get($orderId);
    //       $this->setOrderStatus(
    //         $order,
    //         \Magento\Sales\Model\Order::STATE_PAYMENT_REVIEW,
    //         \Magento\Sales\Model\Order::STATUS_FRAUD,
    //         __('Suspected fraud, captured %1 but order value is %2',[$responseAmount/100,$quote->getGrandTotal()]),
    //         false);
    //     }
    //   }
    // }
    $this->debug("CONVERTED QUOTE: ".$quote->getId()." TO ORDER ".$orderId);
    return $orderId;
  }

  /*
  * Helper Function to Set Order State
  */
  protected function setOrderStatus(&$order, $state, $status, $comment, $isCustomerNotified ) {
      if($status == 'canceled' && !$this->getConfigValue('payment/redsys/order_settings/success_payment_stock_update') && true ){
          $order->registerCancellation($comment);
      }
      else if ($status == 'canceled' && $this->getConfigValue('payment/redsys/order_settings/success_payment_stock_update') && true) {
        $order->setState('closed');// Set the new state
        $order->addStatusToHistory('closed',__('Closed Order for Error or Cancellation'),false);
      }
      else {
          $order->setState($state);// Set the new state
          $order->addStatusToHistory($status,$comment,$isCustomerNotified);// Set a histroy status
      }
      // Save the status
      $order->save();
  }

  public function invalidateCartCookie(){
    $metadata = $this->cookie_metadata_factory
      ->createPublicCookieMetadata()
      ->setPath('/');
    $sectiondata = json_decode($this->cookie_manager->getCookie('section_data_ids'));
    $sectiondata->cart += 1000;
    $this->cookie_manager->setPublicCookie(
        'section_data_ids',
        json_encode($sectiondata),
        $metadata
    );
  }

  public function debug($msg){
    if($this->getConfig('payment/ezenit_waiap/debug')!="0"){
      $this->logger->debug("[WAIAP DEBUG] ".$msg);
    }
  }

  public function critical($msg){
    $this->logger->critical("[WAIAP EXCEPTION] ".$msg);
  }

  public function getConfig($path){
    return $this->config->getValue($path);
  }

  public function getBackendUrl(){
    return $this->url_builder->getUrl('waiap/backend/index');
  }

  public function getUrl($path){
    return $this->url_builder->getUrl($path);
  }

  public function getFlattenJson($jsonData){
    $flatten = new \Sarhan\Flatten\Flatten(".");
    return $flatten->flattenToArray($jsonData);
  }

}
