<?php

namespace Ezenit\Waiap\Helper;

class Constants{
  CONST ENVIROMENTS_URLS = [
    "sandbox" => "https://sandbox.sipay.es/",
    "live"    => "https://live.waiap.com/"
  ];

  CONST SDK_JS_URL = "https://assets-sipay.s3-eu-west-1.amazonaws.com/sdk-js/pwall-sdk.min.js";
}



