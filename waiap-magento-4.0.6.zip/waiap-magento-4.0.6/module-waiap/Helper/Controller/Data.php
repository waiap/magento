<?php

namespace Ezenit\Waiap\Helper\Controller;

class Data
{

  protected $helper;
  protected $checkout;
  protected $result_factory;
  protected $transaction_helper;
  protected $customer_session;
  protected $checkout_session;

  public function __construct(
    \Ezenit\Waiap\Helper\Data                         $helper,
    \Magento\Checkout\Helper\Data                     $checkoutHelper,
    \Magento\Framework\Controller\Result\JsonFactory  $resultJsonFactory,
    \Ezenit\Waiap\Helper\Transaction\Data             $transactionHelper,
    \Magento\Framework\Message\ManagerInterface       $messageManager,
    \Magento\Customer\Model\Session                   $customerSession,
    \Magento\Checkout\Model\Session                   $checkoutSession,
    \Magento\Framework\App\State                      $state,
    \Magento\Framework\Filesystem\DirectoryList       $dir
  ){
    $this->helper               = $helper;
    $this->checkout             = $checkoutHelper;
    $this->result_factory       = $resultJsonFactory;
    $this->transaction_helper   = $transactionHelper;
    $this->_messageManager      = $messageManager;
    $this->customer_session     = $customerSession;
    $this->checkout_session     = $checkoutSession;
    $this->state                = $state;
    $this->dir                  = $dir;
  }

  public function addOrderInfo(&$pwall_request, $quote){
    $pwall_request->setOrderId(strval($quote->getId()));
    $pwall_request->setAmount($quote->getGrandTotal());
    $pwall_request->setCurrency($quote->getQuoteCurrencyCode());
    $pwall_request->setGroupId(strval($quote->getCustomerId() ? $quote->getCustomerId() : 0));
    $pwall_request->setOriginalUrl($this->helper->getUrl("/"));
  }

  public function executeByMethod($jsonRequest, $referrer_url = 'checkout/cart'){
    $result       = $this->result_factory->create();
    $this->helper->debug("ON BACKEND EXECUTE: " . json_encode($jsonRequest));
    $this->customer_session->setWaiapErrorRedirectUrl($referrer_url);

    $client = new \PWall\Client();
    $client->setEnvironment($this->helper->getConfig('payment/ezenit_waiap/environment'));
    $client->setKey($this->helper->getConfig('payment/ezenit_waiap/key'));
    $client->setResource($this->helper->getConfig('payment/ezenit_waiap/resource'));
    $client->setSecret($this->helper->getConfig('payment/ezenit_waiap/secret'));
    $client->setBackendUrl($this->helper->getUrl($this->cleanUrlParams($referrer_url)));
    $debug_enable = $this->helper->getConfig('payment/ezenit_waiap/debug');
    $debug_path = $this->helper->getConfig('payment/ezenit_waiap/debug_path');
    if ($debug_enable == true) {
      if ($debug_path && $debug_path != '') {
        $client->setDebugFile($debug_path);
      } else {
        $client->setDebugFile($this->dir->getPath('log') . "/waiap_sdk.log");
      }
    }

    $quote = $this->checkout->getQuote();
    if($quote->getId()){
      $request = new \PWall\Request(json_encode($jsonRequest), false);
      $this->addOrderInfo($request, $quote);
    }else{
      $request = new \PWall\Request(json_encode($jsonRequest), true);
    }
    $response = $client->proxy($request);
    $result->setJsonData($response->toJSON());

    if ($response->canPlaceOrder()) {
      $quote = $this->checkout->getQuote();
      $orderId = $this->helper->placeOrderFromResponse($response, $jsonRequest["params"]["method"], $quote);
      $this->checkout_session->setLastSuccessQuoteId($quote->getId());
      $this->checkout_session->setLastQuoteId($quote->getId());
      $this->checkout_session->setLastOrderId($orderId);
    }
    return $result;
  }

  private function cleanUrlParams($url){
    //Clean url of query params    
    $parsed_url = parse_url($url);
    if (array_key_exists('query', $parsed_url)) {
      return preg_replace('/\?' . $parsed_url['query'] . '/', '', $url);
    } else {
      return $url;
    }
  }
  
}
